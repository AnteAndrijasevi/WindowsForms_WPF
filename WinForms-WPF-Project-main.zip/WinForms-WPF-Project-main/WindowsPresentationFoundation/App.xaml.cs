﻿using System.Windows;

namespace WindowsPresentationFoundation
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
